## 目标与成功标准

用户能够：导入植物检测数据（Excel）→ 每日记录植物检查状况 → 记录施肥细节（品种、用量、时间）→ 按日期/状态/品种筛选查询 → 导出养护记录为 Excel。

## 关键实现文件

| 文件 | 改动说明 |
|------|---------|
| `server/database/schema.ts` | 新增 `daily_inspection`、`fertilization_record` 两张表 |
| `server/modules/inspection/inspection.module.ts` | 新建巡检模块，统一管理每日检查 + 施肥记录 CRUD |
| `server/modules/inspection/inspection.controller.ts` | 巡检 API 端点 + Excel 导入导出接口 |
| `server/modules/inspection/inspection.service.ts` | 巡检业务逻辑（含 Excel 解析/生成） |
| `server/modules/plant-diagnosis/plant-diagnosis.service.ts` | 增加按品种/状态/日期筛选查询 |
| `server/modules/plant-diagnosis/plant-diagnosis.controller.ts` | 导出 Excel、筛选参数 |
| `shared/api.interface.ts` | 新增 DailyInspection、FertilizationRecord、导出/导入相关类型 |
| `client/src/pages/InspectionsPage/InspectionsPage.tsx` | 新建：每日检查记录页（筛选栏+表格+导入导出按钮） |
| `client/src/pages/HomePage/HomePage.tsx` | 增加快捷入口到巡检页 |
| `client/src/api/inspection.ts` | 新建：巡检 API 调用 |
| `client/src/app.tsx` | 注册 `/inspections` 路由 |
| `client/src/components/Layout.tsx` | 导航增加「每日巡检」菜单项 |
| `package.json` | 新增 `xlsx` 依赖（前后端共用 Excel 解析） |

## 实现方案

### 1. 数据库设计

**daily_inspection 表**（每日检查记录）：
- id, recordId(FK→plant_record), inspectionDate, plantCondition（text：植物状态描述）, appearance（text：外观描述）, leafCondition, soilCondition, pestStatus, images（text：检查照片URL，逗号分隔）, notes, 系统字段

**fertilization_record 表**（施肥记录）：
- id, inspectionId(FK→daily_inspection) 可空，独立施肥记录时为空, recordId(FK→plant_record), fertilizerName（text：肥料名称）, fertilizerType（varchar：organic/chemical/slow_release/liquid）, dosage（text：用量，如"50g/株"）, applicationMethod（varchar：soil_surface/irrigation/foliar_spray）, applicationDate（Date）, nextApplicationDate（Date：下次施肥日期，按正常周期推算）, notes, 系统字段

### 2. 后端改动

- **新建 InspectionModule**（server/modules/inspection/）：统一管理 daily_inspection + fertilization_record 的 CRUD
- **Excel 导入**：POST `/api/inspection/import` 接收上传的 Excel 文件（xlsx），解析后批量写入 daily_inspection 表
- **Excel 导出**：GET `/api/inspection/export` 按筛选条件（日期范围、品种、状态）导出 daily_inspection + fertilization_record 为 Excel
- **施肥周期计算**：创建施肥记录时根据 fertilizerType 自动推算 nextApplicationDate（有机肥 30 天 / 化肥 15 天 / 缓释肥 90 天 / 液肥 7 天）
- **筛选查询**：GET `/api/inspection` 支持按 inspectionDate 范围、recordId、plantCondition 关键词筛选

### 3. 前端改动

- **InspectionsPage**（新建，路由 /inspections）：
  - 顶部筛选栏：品种下拉（动态获取已有的 plantSpecies）、日期范围选择器、状态关键词搜索、「查询」和「刷新」按钮
  - 操作按钮栏：「导入数据」「导出Excel」「新增检查」三个按钮（对齐参考图风格）
  - 数据表格：检查日期、植物品种、外观描述、土壤状态、施肥记录（关联展示）、操作（查看详情）
  - 弹窗新增/编辑检查记录，含植物状态、外观、叶片、土壤、虫害、施肥信息等字段
- **导航更新**：Layout 新增「每日巡检」，HomePage 快捷入口指向 inspections
- **导入功能**：文件上传 → 后端解析 Excel → 返回导入结果 → toast 提示
- **导出功能**：当前筛选条件 → 后端生成 Excel → 浏览器下载

### 4. 代码整理

- 删除 `client/src/pages/ExamplePage/ExamplePage.tsx`（模板残留）
- 统一共享常量引用，确保所有页面使用 `diagnosis-constants.ts`
- 更新 AGENTS.md 路由表和设计规范

## 具体步骤

1. **新增数据库表**（lark-apps-db）：创建 `daily_inspection`、`fertilization_record` 两张表及外键
2. **安装 Excel 依赖**：`npm install xlsx`（前后端共用）
3. **更新 shared/api.interface.ts**：新增 DailyInspection、FertilizationRecord、ImportExport 相关类型
4. **新建 InspectionModule**：controller + service + module，实现 CRUD + Excel 导入导出
5. **注册模块**：app.module.ts 注册 InspectionModule
6. **更新诊断模块**：plant-diagnosis 增加筛选参数和导出接口
7. **新建前端 API 层**：client/src/api/inspection.ts
8. **新建 InspectionsPage**：筛选栏 + 操作按钮栏 + 数据表格 + 新增/编辑弹窗
9. **更新导航和首页**：Layout.tsx + HomePage.tsx
10. **更新路由**：app.tsx 注册 /inspections
11. **清理代码**：删除 ExamplePage，更新 AGENTS.md
12. **E2E 验收**：验证导入导出和巡检功能

## 影响范围与风险

- 新增两张数据库表，不影响现有数据
- 新增 inspection 模块，不影响现有诊断和养护卡功能
- Excel 导入需要用户上传正确格式的文件，需提供模板下载
- 前端依赖 xlsx 包（纯 JS，无 native addon，约 500KB）

## 验收标准

1. 首页能看到「每日巡检」入口，点击跳转 /inspections
2. /inspections 页面有筛选区（品种/日期/关键词）和操作区（导入/导出/新增）
3. 点击「新增检查」弹出表单，含品种选择、状态描述、外观、土壤、施肥信息等字段
4. 新增的检查记录出现在表格中，可按日期和品种筛选
5. 点击「导入数据」可上传 Excel 文件，数据批量入库
6. 点击「导出Excel」按当前筛选条件下载 Excel 文件
7. 施肥记录中自动推算下次施肥日期，按肥料类型显示不同周期
8. 导航栏包含「每日巡检」菜单项