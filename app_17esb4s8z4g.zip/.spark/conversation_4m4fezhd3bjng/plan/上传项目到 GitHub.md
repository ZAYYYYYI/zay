# 上传到 GitHub 方案

## 目标与成功标准

将当前 `sprint/default` 分支代码推送到 `https://github.com/Vince-good/AgricultureSoftware.git`，GitHub 仓库可见完整项目源码。

## 关键实现文件

无代码文件修改，仅 Git 操作。

## 实现方案

1. **先提交当前未提交的改动**（巡检模块代码）：使用 `commit_task` 工具提交到平台 Git
2. **添加 GitHub 远程仓库**：`git remote add github https://github.com/Vince-good/AgricultureSoftware.git`
3. **推送到 GitHub**：`git push github sprint/default:main`（推送到 GitHub 的 main 分支，因为 GitHub 默认分支通常为 main）

## 具体步骤

| 步骤 | 操作 | 说明 |
|------|------|------|
| 1 | 调用 `commit_task` 提交巡检模块改动 | 将当前所有未提交文件提交到 platform git |
| 2 | `git remote add github <url>` | 添加 GitHub 作为第二个远程仓库 |
| 3 | `git push github sprint/default:main` | 推送到 GitHub 的 main 分支 |

## 影响范围与风险

- **认证**：推送到 GitHub 需要 HTTPS 凭据（Personal Access Token 或用户名密码）。如果沙箱未配置 GitHub 凭据，推送可能失败，需要在 GitHub 上创建 Personal Access Token
- **分支名映射**：本地 `sprint/default` 推送到 GitHub `main` 分支，避免 GitHub 上的默认分支混乱
- **平台 Git 不受影响**：`origin` 指向平台 Git 不变，后续开发不受影响

## 验收标准

- GitHub 仓库 `Vince-good/AgricultureSoftware` 的 main 分支能看到完整项目代码
- 本地 `origin` 仍指向平台 Git，后续 `commit_task` 正常工作